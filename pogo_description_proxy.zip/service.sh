#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot to complete and network to be ready
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

# Run socat proxy in the background
# Listens on port 9001, forwards to Render SSL port 443 without certificate verification
# Runs in background (&) so it never blocks the Android boot sequence (prevents bootloops)
$MODDIR/socat TCP-LISTEN:9001,fork,reuseaddr OPENSSL:pokexpert-description-writer-tg.onrender.com:443,verify=0 &
