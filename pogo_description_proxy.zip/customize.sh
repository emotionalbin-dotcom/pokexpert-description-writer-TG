#!/system/bin/sh
# Set executable permission for the socat binary during installation
ui_print "- Setting executable permissions for socat..."
set_perm $MODPATH/socat 0 0 0755
